import urllib.parse
from sqlalchemy import create_engine
import pandas as pd
import time
from datetime import datetime


### DEEPAK LAPTOP DB
# db_user = urllib.parse.quote_plus("postgres")
# db_pass = urllib.parse.quote_plus("pgadmin")
# engine = create_engine(f'postgresql+psycopg2://{db_user}:{db_pass}@localhost:5432/ibm_atombridge_db?sslmode=', client_encoding='utf8' )


### CT TEAM STAGIING DB 
# db_user = urllib.parse.quote_plus("devuser1@usedadvsampql01")
# db_pass = urllib.parse.quote_plus("Devuser1@3")
# engine = create_engine(f'postgresql+psycopg2://{db_user}:{db_pass}@usedadvsampql01.postgres.database.azure.com:5432/ey_atombridge_db?sslmode=require', client_encoding='utf8' )

### Production TEAM STAGIING DB 
db_user = urllib.parse.quote_plus("postgres")
db_pass = urllib.parse.quote_plus("portaluser@8877")
engine = create_engine(f'postgresql+psycopg2://{db_user}:{db_pass}@atomclient.westcentralus.cloudapp.azure.com:5432/ey_atom_core_db?sslmode=', client_encoding='utf8' )
# engine = create_engine(f'postgresql+psycopg2://{db_user}:{db_pass}@atomclient.westcentralus.cloudapp.azure.com:5432/ibm_atombridge_db?sslmode=', client_encoding='utf8' )

connection = engine.raw_connection() #TODO connection pooling required
cursor = connection.cursor() #TODO connection pooling required

#HW_Baseline_MLDB_20220303.xlsx #TODO CHange to xlsx and code again with 
# csv_file = '/home/vcenteruser/ibm_new/sprint3/a_csv/SCAN_DATA_VM_20210325_1.CSV'
csv_file = f'C:/project/feb24 _sample_file/SCAN_DATA_VM_20210325_1.CSV'

# csv_load_staging = '/home/vcenteruser/ibm_new/sprint3/b_csv/DF_vmware_load_staging_'+str(datetime.now().date())+'_.csv'
csv_load_staging = f'C:/project/Server_data_download/server_small_df/DF_vmware_load_staging_'+str(datetime.now().date())+'_.csv'

start_time_copy_expert = time.time()
df_original = pd.read_csv(csv_file)
#df_original.drop(df_original.columns[0], axis=1,inplace=True) # DROP COL == SR NO 
print("----df_original.shape------",df_original.shape)
#print(df_original.head(2))
ls_cols_staging = ['UpdatedOn', 'UpdatedBy', 'Source', 'VmwareHwTAgs']
# cols_original = []
cols_to_drop = ['CNDB_ID','SCRIPT_TIMESTAMP','VMS_SCRIPT_NAME']

# MACHINE_TYPE -- Not to go to PRODUCTION - Only till STAGING - Viresh Mapping XLSX
# HW_SERIAL_NUMBER - Not to go to PRODUCTION - Only till STAGING - Viresh Mapping XLSX
# CAMPUS_ID - Not to go to PRODUCTION - Only till STAGING - Viresh Mapping XLSX

df_original.drop(columns=cols_to_drop, axis=1,inplace=True)
## Dropped -- 18MARCH -- AccountNumber ... replaced with == CNDBId
## below MAPPING DICT -- dict_cols_mapping -- follows ORDER of the CSV Columns 
dict_cols_mapping = {
						'VMS_VMNAME' : 'VmName',
						'VMS_VMUNIQID' : 'VmUniqId',
						'VMS_VMPOWERSTATE' : 'VmPowerState',
						'VMS_VMUPTIMEDAYS' : 'VmUptimeDays',
						'VMS_VMOS' : 'VmOS',
						'VMS_VMCPU' : 'VmCPU',
						'VMS_VMCOREPERSCKT' : 'VmCorePerSckt',
						'VMS_VMCPUSKTS' : 'VmCPUSkts',
						'VMS_HSNAME' : 'HsName',
						'VMS_HSUNIQID' : 'HsUniqId',
						'VMS_HSSTATUS' : 'HsStatus',
						'VMS_HSMANUFACTURER' : 'HsManufacturer',
						'VMS_HSHWTYPE' : 'HsHWType',
						'VMS_HSSERIAL' : 'HsSerial',
						'VMS_HSOS' : 'HsOS',
						'VMS_HSOSVER' : 'HsOSver',
						'VMS_HSOSBLD' : 'HsOSbld',
						'VMS_HSMEMORYSIZEGB' : 'HsMemorySizeGB',
						'VMS_CLUNAME' : 'CluName',
						'VMS_CLUHAENABLED' : 'CluHAEnabled',
						'VMS_VMHAPROT' : 'VmHAprot',
						'VMS_CLUDRSENABLED' : 'CluDrsEnabled',
						'VMS_CLUDRSAUTOLVL' : 'CluDrsAutoLvl',
						'VMS_VMDRSPROT' : 'VmDRSprot',
						'VMS_VMCANMIGRATE' : 'VmCanMigrate',
						'VMS_VMMIGINF' : 'VmMigInf',
						'VMS_VMAUTOVMOTION' : 'VMAutoVMotion',
						'VMS_HSCPUMODEL' : 'HsCPUModel',
						'VMS_HSCPUSOCKETS' : 'HsCPUSockets',
						'VMS_HSCPUCORES' : 'HsCPUCores',
						'VMS_HSCPUTHREADS' : 'HsCPUThreads',
						'VMS_HSCPUHYPERTHREADING' : 'HsCPUHyperThreading',
						'VMS_GTIMESTAMP' : 'GTimeStamp',
						'VMS_VMNAME2' : 'VmName2',
						'VMS_VMSTATE' : 'VmState',
						'VMS_VMTOOLS' : 'VmTools',
						'VMS_VMTOOLSVER' : 'VmToolsVer',
						'VMS_VMOSSOURCE' : 'VmOSSource',
						'VMS_VCENTERNAME' : 'VCenterName',
					}

df_original.rename(columns=dict_cols_mapping, inplace=True)
print(df_original.columns)
cols_db = []
ls_append_rows = []
for i in range(df_original.shape[0]):
	ls_append_rows.append([str(datetime.now().date()),'Atom_Bridge', 'Source_vmwaredata', '{"1TF": "Inprocess"}'])

df_staging_append = pd.DataFrame(ls_append_rows, columns = ls_cols_staging)
print("-----df_staging_append.shape--------",df_staging_append.shape)
print(df_staging_append.head(2))
#df_load_staging = pd.concat([df_staging_append,df_original],axis=1, join="inner")
df_load_staging = pd.concat([df_staging_append,df_original],axis=1)
cols_final = ['UpdatedOn','UpdatedBy','Source','VmwareHwTAgs','VmName',
				'VmUniqId','VmPowerState','VmUptimeDays','VmOS','VmCPU',
				'VmCorePerSckt','VmCPUSkts','HsName','HsUniqId','HsStatus',
				'HsManufacturer','HsHWType','HsSerial','HsOS','HsOSver',
				'HsOSbld','HsMemorySizeGB','CluName','CluHAEnabled','VmHAprot',
				'CluDrsEnabled','CluDrsAutoLvl','VmDRSprot','VmCanMigrate',
				'VmMigInf','HsCPUModel','HsCPUSockets','HsCPUThreads','HsCPUCores',
				'HsCPUHyperThreading','GTimeStamp','VmName2','VmState',
				'VmTools','VmToolsVer','VmOSSource','VCenterName','VMAutoVMotion'
				]

#TODO -- cols_final - needs to come from CONFIG.ini
## Dropped -- 18MARCH -- AccountNumber ... replaced with == CNDBId
df_load_staging = df_load_staging.reindex(columns=cols_final) 
# df_load_staging.columns=cols_final
df_load_staging.to_csv(csv_load_staging,index=False)
print("----df_load_staging.shape----------",df_load_staging.shape)
print(df_load_staging.head(2))

# df_load_staging_csv_path = '/home/vcenteruser/ibm_new/sprint3/b_csv/DF_mldb_load_staging_'+str(datetime.now().date())+'_.csv'
# df_load_staging.to_csv(df_load_staging_csv_path,index=False)

# tbl_bridge_staging = 'tbl_bridge_ibm_vmware_hw_inventory'
tbl_bridge_staging = 'bridge.tbl_ibm_vmware_hw_inventory'
sql = "COPY " + tbl_bridge_staging + " FROM STDIN DELIMITER \',\' CSV header;"
cursor.copy_expert(sql,open(csv_load_staging))
connection.commit()
end_time = time.time()
seconds_copy_expert = end_time - start_time_copy_expert
print("time taken seconds - copy_expert",seconds_copy_expert)
cursor.close()
