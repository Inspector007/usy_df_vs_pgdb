import sys
import urllib.parse
from sqlalchemy import create_engine
import time, uuid, json
import pandas as pd
import numpy as np
from datetime import datetime
import re, json

"""
"""
### DEEPAK LAPTOP DB
# db_user = urllib.parse.quote_plus("postgres")
# db_pass = urllib.parse.quote_plus("pgadmin")
# engine = create_engine(f'postgresql+psycopg2://{db_user}:{db_pass}@localhost:5432/ibm_atombridge_db?sslmode=', client_encoding='utf8' )

### CT TEAM STAGIING DB 
# db_user_staging = urllib.parse.quote_plus("devuser1@usedadvsampql01")
# db_pass_staging = urllib.parse.quote_plus("Devuser1@3")
# engine = create_engine(f'postgresql+psycopg2://{db_user_staging}:{db_pass_staging}@usedadvsampql01.postgres.database.azure.com:5432/ey_atombridge_db?sslmode=require', client_encoding='utf8' )

### Production TEAM STAGIING DB 
db_user = urllib.parse.quote_plus("postgres")
db_pass = urllib.parse.quote_plus("portaluser@8877")
engine = create_engine(f'postgresql+psycopg2://{db_user}:{db_pass}@atomclient.westcentralus.cloudapp.azure.com:5432/ibm_atombridge_db?sslmode=', client_encoding='utf8' )

connection = engine.raw_connection()
cursor = connection.cursor()

#177792 -  LPAR detailed report 2021-02-11.xls
#177792_LPAR_detailed_report_2021-02-11.xls

csv_file = '/home/vcenteruser/ibm_new/sprint3/a_csv/177792_LPAR_detailed_report_2021-02-11.csv'
# csv_file = f'C:/project/feature_box_poc_1_box_connector/177792_LPAR_detailed_report_2021-02-11.csv'
df_original = pd.read_csv(csv_file)
print("----df_original.shape------", df_original.shape)
# csv_load_staging = '/home/vcenteruser/ibm_new/sprint3/b_csv/TADZ_LPAR_PreProcess_' + str(datetime.now().date()) + '_.csv'
# csv_load_staging = '/home/vcenteruser/ibm_new/sprint3/b_csv/TADZ_LPAR_PreProcess_' + str(datetime.now().date()) + '_.csv'
start_time_copy_expert = time.time()
ls_cols_staging = ['UpdatedOn', 'UpdatedBy','HwInventoryTags','Source']
# IsShare -- Not in the CSV - Vireshwar has added this extra column
cols_original = ['TSID','SID','SMFID','SYSPLEX','HW_TYPE','HW_MODEL','HW_PLANT','HW_NAME','LPAR_NAME','NODE_LAST_UPDATE','CPU_SN']
#cols_to_drop = ['SR_NO']
#df_original.drop(columns=cols_to_drop, axis=1, inplace=True)

# SELECT * FROM tbl_bridge_ibm_tadz_lpar_staging;
#  UpdatedOn | UpdatedBy | TsId | SId | SmfId | SysPlex | HwType | HwModel | HwPlant | HwName | LparName | NodeLastUpdate | CpuSn | HwInventoryTags | Source
# -----------+-----------+------+-----+-------+---------+--------+---------+---------+--------+----------+----------------+-------+-----------------+--------
# (0 rows)

dict_cols_mapping = {"TSID": "TsId",
                     "SID": "SId",
                     "SMFID": "SmfId",
                     "SYSPLEX": "SysPlex",
                     "HW_TYPE": "HwType",
                     "HW_MODEL": "HwModel",
                     "HW_PLANT": "HwPlant",
                     "HW_NAME": "HwName",
                     "LPAR_NAME": "LparName",
                     "NODE_LAST_UPDATE": "NodeLastUpdate",
                     "CPU_SN": "CpuSn"
                     }
df_original.rename(columns=dict_cols_mapping, inplace=True)
ls_append_rows = []
for i in range(df_original.shape[0]):
    ls_append_rows.append(
        [str(datetime.now().date()), 'Atom_Bridge', '{"1TF": "Inprocess"}', 'TadZ_LPAR'])
df_staging_append = pd.DataFrame(ls_append_rows, columns=ls_cols_staging)
print("-----df_staging_append.shape---", df_staging_append.shape)

# df_load_staging = pd.concat([df_staging_append,df_original],axis=1, join="inner")
df_load_staging = pd.concat([df_staging_append, df_original], axis=1)
cols_final = ['UpdatedOn','UpdatedBy','TsId','SId','SmfId',
            'SysPlex','HwType','HwModel','HwPlant','HwName','LparName',
            'NodeLastUpdate','CpuSn','HwInventoryTags','Source',]
# TODO -- cols_final - needs to come from CONFIG.ini
## Dropped -- 18MARCH -- AccountNumber ... replaced with == CNDBId
df_load_staging = df_load_staging.reindex(columns=cols_final)
# df_load_staging.to_csv(csv_load_staging,index=False)
print("----df_load_staging.shape-------QA TEAM DEMO --- 30MARCH-", df_load_staging.shape)

df_load_staging_csv_path = '/home/vcenteruser/ibm_new/sprint3/b_csv/DF_tadz_load_staging_' + str(
    datetime.now().date()) + '_.csv'
# df_load_staging_csv_path = f'C:/project/feature_box_poc_1_box_connector/DF_tadz_load_staging_' + str(
#     datetime.now().date()) + '_.csv'

df_load_staging.to_csv(df_load_staging_csv_path, index=False)
sql = "COPY tbl_bridge_ibm_tadz_lpar_staging FROM STDIN DELIMITER \',\' CSV header;"
cursor.copy_expert(sql, open(df_load_staging_csv_path))
connection.commit()
end_time = time.time()
seconds_copy_expert = end_time - start_time_copy_expert
print("time taken seconds - copy_expert", seconds_copy_expert)
cursor.close()


